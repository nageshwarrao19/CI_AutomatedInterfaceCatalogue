/*
 * This Groovy script generates an Excel workbook attachment based on the message body XML. 
 * The script uses Apache POI library for Excel generation. 
 * Apache POI reference - https://poi.apache.org/components/spreadsheet/
 */
import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.camel.impl.DefaultAttachment
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.*
import org.apache.poi.ss.util.*
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.BorderStyle;
import javax.activation.DataHandler;
import javax.mail.util.ByteArrayDataSource;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message processData(Message message) {
    
    def dateFormat = new SimpleDateFormat("dd-MM-yyyy") // Set the date format as per your requirement
    def currentDate = new Date()
    def formattedDate = dateFormat.format(currentDate)
    
    // Extract the source XML from the message body
    def sourceXml = message.getBody(String.class)
    
    // Parse the source XML to extract records
    def integrationArtifacts = new XmlSlurper().parseText(sourceXml).'**'.findAll { it.name() == 'IntegrationArtifact' }
    
    //Defining column names in header row.
    String[] titles = ["Sr.No","Iflow Name","Description","ID", "Package ID","Version","Sender","Receiver","Status","Deployed By","Deployed On", "URL", "Protocol", "Configurations - ParameterName:ParameterValue"];
    
    // Create a new workbook
    Workbook workbook = new XSSFWorkbook()
    
    // Create a sheet in the workbook with appropriate name
    Sheet sheet = workbook.createSheet("SAP CI Interfaces - " + "("+integrationArtifacts.size()+")")
    
    // define cell styles for title row
    CellStyle titleStyle = workbook.createCellStyle()
    Font titleFont = workbook.createFont()
    titleFont.setBold(true)
    titleFont.setColor(IndexedColors.WHITE.getIndex())
    titleFont.setFontHeightInPoints((short)17)
    titleStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex())
    titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)
    titleStyle.setFont(titleFont)
    titleStyle.setAlignment(HorizontalAlignment.CENTER)
    titleStyle.setVerticalAlignment(VerticalAlignment.CENTER)
    
    //title row
    Row titleRow = sheet.createRow(0)
    Cell titleCell = titleRow.createCell(0)
    titleCell.setCellValue("SAP Cloud Interface Catalogue - "+formattedDate)
    sheet.addMergedRegion(CellRangeAddress.valueOf("A1:N1"))
    titleRow.getCell(0).setCellStyle(titleStyle)
    
    // define cell styles for header and data
    CellStyle headerStyle = workbook.createCellStyle();
    def headerFont = workbook.createFont()
    headerFont.bold = true
    headerFont.setFontHeightInPoints((short)13)
    headerStyle.setFont(headerFont)
    headerStyle.setAlignment(HorizontalAlignment.LEFT)
    headerStyle.setVerticalAlignment(VerticalAlignment.CENTER)
    
    // Create a header row with column names
    Row headerRow = sheet.createRow(1);
    headerRow.setHeightInPoints(16);
    Cell headerCell;
    for (int i = 0; i < titles.length; i++) {
        headerCell = headerRow.createCell(i);
        headerCell.setCellValue(titles[i]);
        headerRow.getCell(i).setCellStyle(headerStyle);
        sheet.autoSizeColumn(i)
    }
    
    // Define cell style for center and left alignment
    CellStyle centerLeftStyle = workbook.createCellStyle();
    centerLeftStyle.setAlignment(HorizontalAlignment.LEFT);
    centerLeftStyle.setVerticalAlignment(VerticalAlignment.CENTER);
    centerLeftStyle.setWrapText(false);
    
    // Define cell style for top left alignment with wrap text
    CellStyle topLeftStyle = workbook.createCellStyle();
    topLeftStyle.setAlignment(HorizontalAlignment.LEFT);
    topLeftStyle.setVerticalAlignment(VerticalAlignment.TOP);
    topLeftStyle.setWrapText(true);
    
    int rownum = 1;    
    
    // Populate data in rows
    for(int i = 0; i < integrationArtifacts.size(); i++) {
    def integrationArtifact = integrationArtifacts[i]
    def integrationDesignTimeArtifact = integrationArtifact.IntegrationDesigntimeArtifact
    def integrationRuntimeArtifact = integrationArtifact.IntegrationRuntimeArtifact[0]
    def configurations = integrationArtifact.Configurations[0]
    
    Row row = sheet.createRow(rownum+1)
    
    row.createCell(0).setCellValue(i+1)
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 0, 0));
    }
    row.createCell(1).setCellValue(integrationDesignTimeArtifact.Parameter.Name.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 1, 1));
    } 
    row.createCell(2).setCellValue(integrationDesignTimeArtifact.Parameter.Description.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 2, 2));
    }
    row.createCell(3).setCellValue(integrationArtifact.Id.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 3, 3));
    }
    row.createCell(4).setCellValue(integrationDesignTimeArtifact.Parameter.PackageId.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 4, 4));
    }
    row.createCell(5).setCellValue(integrationDesignTimeArtifact.Parameter.Version.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 5, 5));
    }
    row.createCell(6).setCellValue(integrationDesignTimeArtifact.Parameter.Sender.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 6, 6));
    }
    row.createCell(7).setCellValue(integrationDesignTimeArtifact.Parameter.Receiver.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 7, 7));
    }    
    row.createCell(8).setCellValue(integrationRuntimeArtifact.Status.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 8, 8));
    }    
    row.createCell(9).setCellValue(integrationRuntimeArtifact.DeployedBy.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 9, 9));
    }
    row.createCell(10).setCellValue(integrationRuntimeArtifact.DeployedOn.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 10, 10));
    }
    row.createCell(11).setCellValue(integrationRuntimeArtifact.ServiceEndpoint.EntryPoints.EntryPoint.Url.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 11, 11));
    }
    row.createCell(12).setCellValue(integrationRuntimeArtifact.ServiceEndpoint.Protocol.text())
    if (configurations.Parameter.size() > 1) {
        sheet.addMergedRegion(new CellRangeAddress(rownum+1, rownum+configurations.Parameter.size(), 12, 12));
    }
    
    int configRowNum = rownum + 1
    for(int x=0; x<configurations.Parameter.size();x++)
        {
            Row configRow = sheet.getRow(configRowNum)
            if (configRow == null) {
            configRow = sheet.createRow(configRowNum)
        }
        configRow.createCell(13).setCellValue(configurations.Parameter[x].ParameterKey.text() + " : " + configurations.Parameter[x].ParameterValue.text())
        configRowNum++
    }
        
    rownum = configRowNum-1
        
        // set cell style for all cells in each row
        (0..13).each { j ->
        def style = centerLeftStyle // use default 
            if(j== 0){
                style = headerStyle
            }
            if (j == 2 || j == 11) {
                style = topLeftStyle // use different style for columns 2 and 11
            }
        row.getCell(j).setCellStyle(style)
        sheet.autoSizeColumn(j)
        }
        sheet.createFreezePane(0, 2); // Freeze the first row and first column
    }

    
    // Convert workbook to byte array
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()
    workbook.write(byteArrayOutputStream)
    byte[] bytes = byteArrayOutputStream.toByteArray()
    
    // Construct a ByteArrayDataSource object with the byte array and the content's MIME type
    ByteArrayDataSource dataSource = new ByteArrayDataSource(bytes, "application/vnd.ms-excel")
    
    // Construct a DefaultAttachment object
    DataHandler dataHandler = new DataHandler(dataSource)
    DefaultAttachment attachment = new DefaultAttachment(dataHandler)
    
    // Add the attachment to the message
    message.addAttachmentObject("SAP_CloudInterfaceCatalogue_"+formattedDate+".xlsx", attachment)
    
    return message
}
